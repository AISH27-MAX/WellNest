# WellNest-A-Hospital-Management-Platform
 A project based on HTML, CSS, JavaScript.
